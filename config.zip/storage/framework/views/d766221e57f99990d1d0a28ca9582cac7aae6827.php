
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
          <div class="d-flex justify-content-between">
            <h3>Add New Post</h3>
            <a href="<?php echo e(url('allpost')); ?>" class="btn btn-success">Back to All Post</a>
          </div>
        </div>
        <div class="card-body">
            
            <form action="<?php echo e('insertpost'); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="row">
                <div class="form-group col-sm-6">
                  <label for="email">Title:</label>
                  <input type="text" name="title" class="form-control" value="">
                </div>
                <div class="form-group col-sm-6">
                  <label for="email">Description:</label>
                  <input type="text" name="desctiption" class="form-control" value="">
                </div>

                <div class="form-group col-sm-6">
                  <label for="email">Image:</label>
                  <input type="file" name="image" class="form-control" placeholder="Image">
                </div>

                <div class="form-group col-sm-6">
                  <label for="email">Category</label>
                  <select name="pets" id="pet-select">
                    <option value="">--Select Category--</option>
                    <option value="dog">Dog</option>
                    <option value="cat">Cat</option>
                </select>
                </div>
                           
              </div>
              <br>
                <button type="submit" class="btn btn-primary">Submit</button>
                
              </form>
        </div>
        <div class="card-footer">Footer</div>
      </div>
   
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('backend/layout/admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\project-6\resources\views/backend/blog/create_post.blade.php ENDPATH**/ ?>