
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
          <div class="d-flex justify-content-between">
            <h3>Add New Category</h3>
            <a href="<?php echo e(url('allcategory')); ?>" class="btn btn-success">Back to Category</a>
          </div>
        </div>
        <div class="card-body">
            
            <form action="<?php echo e('insertcategory'); ?>" method="post" enctype="multipart/form-data">
           <?php echo csrf_field(); ?>
              <div class="row">
                <div class="form-group col-sm-6">
                  <label for="category_name">Category Name :</label>
                  <input type="text" name="category_name" class="form-control" value="">
                </div>
                           
              </div>
              <br>
                <button type="submit" class="btn btn-primary">Submit</button>
                
              </form>
        </div>
        <div class="card-footer">Footer</div>
      </div>
   
</div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('backend/layout/admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\project-6\resources\views/backend/category/create_category.blade.php ENDPATH**/ ?>