
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
          <div class="d-flex justify-content-between">
            <h3>Add New Choose</h3>
            <a href="<?php echo e(url('allchoose')); ?>" class="btn btn-success">Back to Choose</a>
          </div>
        </div>
        <div class="card-body">
            
            <form action="<?php echo e('insertchoose'); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
              <div class="row">
                <div class="form-group col-sm-6">
                  <label for="email">Choose Title:</label>
                  <input type="text" name="choo_title" class="form-control" value="">
                </div>
                <div class="form-group col-sm-6">
                  <label for="email">Choose Description:</label>
                  <input type="text" name="choo_desc" class="form-control" value="">
                </div>

                <div class="form-group col-sm-6">
                  <label for="email">Image:</label>
                  <input type="file" name="choo_image" class="form-control" placeholder="Image">
                </div>
              
                <div class="form-group col-sm-6">
                  <label for="cars">Select Background Color:</label>

                  <select id="cars">
                    <option value="volvo">Volvo</option>
                    <option value="saab">Saab</option>
                    <option value="vw">VW</option>
                    <option value="audi" selected>Audi</option>
                  </select> 
                </div>
             
              </div>
              <br>
                <button type="submit" class="btn btn-primary">Submit</button>
                
              </form>
        </div>
        <div class="card-footer">Footer</div>
      </div>
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend/layout/admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\project-6\resources\views/backend/choose/create_choose.blade.php ENDPATH**/ ?>