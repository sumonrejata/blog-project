
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
          <div class="d-flex justify-content-between">
            <h3>Edit Courses</h3>
            <a href="<?php echo e(url('allourcourses')); ?>" class="btn btn-success">Back to Courses</a>
          </div>
        </div>
        <div class="card-body">
            
            <form action="<?php echo e(url('updatecourses')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="EditId" value="<?php echo e($ourcourses->id); ?>">
              <div class="row">
                <div class="form-group col-sm-6">
                  <label for="email">Admission:</label>
                  <input type="text" name="admission" class="form-control" value="<?php echo e($ourcourses->admission); ?>">
                </div>
                <div class="form-group col-sm-6">
                  <label for="email">Courses Title:</label>
                  <input type="text" name="courses_title" class="form-control" value="<?php echo e($ourcourses->title); ?>">
                </div>

                <div class="form-group col-sm-6">
                  <label for="email">Description :</label>
                  <input type="text" name="description" class="form-control" value="<?php echo e($ourcourses->description); ?>">
                </div>

                <div class="form-group col-sm-6">
                  <label for="email">Cradit :</label>
                  <input type="text" name="cradit" class="form-control" value="<?php echo e($ourcourses->cradit); ?>">
                </div>

                <div class="form-group col-sm-6">
                  <label for="email">Duration :</label>
                  <input type="text" name="duration" class="form-control" value="<?php echo e($ourcourses->duration); ?>">
                </div>

                <div class="form-group col-sm-6">
                  <label for="email">Image:</label>
                  <input type="file" name="image" class="form-control" placeholder="Image">
                </div>
                
                <img src="<?php echo e(asset( $ourcourses->image)); ?>" alt="" style="width: 250px;height:150px;">  
                           
              </div>
              <br>
                <button type="submit" class="btn btn-primary">Submit</button>
                
              </form>
        </div>
        <div class="card-footer">Footer</div>
      </div>
   
</div>

  <?php $__env->stopSection(); ?>


<?php echo $__env->make('backend/layout/admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\project-6\resources\views/backend/ourcourses/edit_courses.blade.php ENDPATH**/ ?>