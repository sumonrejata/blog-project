<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Glaxdu - Education Bootstrap 5 Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
    
    <!-- CSS
	============================================ -->
   
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frondend')); ?>/assets/css/bootstrap.min.css">
    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frondend')); ?>/assets/css/icons.min.css">
    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frondend')); ?>/assets/css/plugins.css">
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frondend')); ?>/assets/css/style.css">
    <!-- Modernizer JS -->
    <script src="<?php echo e(asset('frondend')); ?>/assets/js/vendor/modernizr-3.11.7.min.js"></script>
</head><?php /**PATH G:\project-6\resources\views/frondend/header.blade.php ENDPATH**/ ?>