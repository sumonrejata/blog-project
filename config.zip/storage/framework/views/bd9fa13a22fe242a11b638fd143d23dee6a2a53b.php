
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
          <div class="d-flex justify-content-between">
            <h3>Add New Student</h3>
            <a href="<?php echo e(url('student')); ?>" class="btn btn-success">Back to Student</a>
          </div>
        </div>
        <div class="card-body">
        
            <form action="<?php echo e(url('studentupdate')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php echo e($student->id); ?>

              <input type="hidden" name="EditId" value="<?php echo e($student->id); ?>">
              <div class="row">
                <div class="form-group col-sm-6">
                  <label for="email">Student Name:</label>
                  <input type="text" name="st_name" class="form-control" value="<?php echo e($student->st_name); ?>">
                </div>
                <div class="form-group col-sm-6">
                  <label for="email">Student Roll:</label>
                  <input type="text" name="st_roll" class="form-control" value="<?php echo e($student->st_roll); ?>">
                </div>

                <div class="form-group col-sm-6">
                  <label for="email">Department:</label>
                  <input type="text" name="st_depertment" class="form-control" value="<?php echo e($student->st_depertment); ?>">
                </div>
                <div class="form-group col-sm-6">
                  <label for="email">Image:</label>
                  <input type="file" name="st_image" class="form-control" placeholder="Image">
                </div> 
                <img src="<?php echo e(asset( $student->st_image)); ?>" alt="" style="width: 250px;height:150px;">                
              </div>
              <br>
                <button type="submit" class="btn btn-primary">Submit</button>
                
              </form>
        </div>
        <div class="card-footer">Footer</div>
      </div>
   
</div>

  <?php $__env->stopSection(); ?>


<?php echo $__env->make('backend/layout/admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\project-6\resources\views/backend/student/student_edit.blade.php ENDPATH**/ ?>