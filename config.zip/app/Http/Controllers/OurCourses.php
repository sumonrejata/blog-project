<?php

namespace App\Http\Controllers;
// use App\Models\OurCourses;

use Illuminate\Http\Request;

class OurCourses extends Controller
{
    
}
